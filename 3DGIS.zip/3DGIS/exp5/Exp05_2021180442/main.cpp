#include "header.h"

// ȫ�ֱ�������
float terrain[terrainSize][terrainSize];
float angleX = 45.0f, angleY = 0.0f;
float zoom = 1.0f;

// ������ɵ���
void generateTerrain() {
    srand(static_cast<unsigned>(time(0)));
    for (int i = 0; i < terrainSize; ++i) {
        for (int j = 0; j < terrainSize; ++j) {
            terrain[i][j] = static_cast<float>(rand()) / RAND_MAX * 20.0f;
        }
    }

    // ƽ������
    for (int i = 1; i < terrainSize - 1; ++i) {
        for (int j = 1; j < terrainSize - 1; ++j) {
            terrain[i][j] = (terrain[i][j] + terrain[i + 1][j] + terrain[i - 1][j] + terrain[i][j + 1] + terrain[i][j - 1]) / 5.0f;
        }
    }
}

// ���ݸ߶�������ɫ
void setColor(float height) {
    if (height < 5.0f) glColor3f(0.0f, 0.5f, 0.0f); // �͵�
    else if (height < 10.0f) glColor3f(0.5f, 0.5f, 0.0f); // �е͵�
    else if (height < 15.0f) glColor3f(0.5f, 0.25f, 0.0f); // �иߵ�
    else glColor3f(0.5f, 0.0f, 0.0f); // �ߵ�
}

// ��ֵ��ɫ
void interpolateColor(float height) {
    float r = (height / 20.0f) * 0.5f;
    float g = (1.0f - height / 20.0f) * 0.5f;
    float b = 0.0f;
    glColor3f(r, g, b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // �ƶ����������м䣬����������
    glTranslatef(-100.0f, -10.0f, -terrainSize * 1.5f * zoom);

    // ��ת���������м�
    glTranslatef(terrainSize / 2.0f, 0.0f, terrainSize / 2.0f);
    glRotatef(angleX, 1.0f, 0.0f, 0.0f);
    glRotatef(angleY, 0.0f, 1.0f, 0.0f);
    glTranslatef(-terrainSize / 2.0f, 0.0f, -terrainSize / 2.0f);

    glBegin(GL_QUADS);
    // ���Ƶ���
    for (int i = 0; i < terrainSize - 1; ++i) {
        for (int j = 0; j < terrainSize - 1; ++j) {
            setColor(terrain[i][j]);
            glVertex3f(i, terrain[i][j], j);

            setColor(terrain[i + 1][j]);
            glVertex3f(i + 1, terrain[i + 1][j], j);

            setColor(terrain[i + 1][j + 1]);
            glVertex3f(i + 1, terrain[i + 1][j + 1], j + 1);

            setColor(terrain[i][j + 1]);
            glVertex3f(i, terrain[i][j + 1], j + 1);
        }
    }

    // ���Ƶ����ıߵ�Χ��
    for (int i = 0; i < terrainSize - 1; ++i) {
        // ǰ�߽�
        interpolateColor(terrain[i][0]);
        glVertex3f(i, terrain[i][0], 0);
        interpolateColor(terrain[i + 1][0]);
        glVertex3f(i + 1, terrain[i + 1][0], 0);
        interpolateColor(0);
        glVertex3f(i + 1, 0, 0);
        interpolateColor(0);
        glVertex3f(i, 0, 0);

        // ��߽�
        interpolateColor(terrain[i][terrainSize - 1]);
        glVertex3f(i, terrain[i][terrainSize - 1], terrainSize - 1);
        interpolateColor(terrain[i + 1][terrainSize - 1]);
        glVertex3f(i + 1, terrain[i + 1][terrainSize - 1], terrainSize - 1);
        interpolateColor(0);
        glVertex3f(i + 1, 0, terrainSize - 1);
        interpolateColor(0);
        glVertex3f(i, 0, terrainSize - 1);

        // ��߽�
        interpolateColor(terrain[0][i]);
        glVertex3f(0, terrain[0][i], i);
        interpolateColor(terrain[0][i + 1]);
        glVertex3f(0, terrain[0][i + 1], i + 1);
        interpolateColor(0);
        glVertex3f(0, 0, i + 1);
        interpolateColor(0);
        glVertex3f(0, 0, i);

        // �ұ߽�
        interpolateColor(terrain[terrainSize - 1][i]);
        glVertex3f(terrainSize - 1, terrain[terrainSize - 1][i], i);
        interpolateColor(terrain[terrainSize - 1][i + 1]);
        glVertex3f(terrainSize - 1, terrain[terrainSize - 1][i + 1], i + 1);
        interpolateColor(0);
        glVertex3f(terrainSize - 1, 0, i + 1);
        interpolateColor(0);
        glVertex3f(terrainSize - 1, 0, i);
    }
    glEnd();

    // ���Ƶ���
    glBegin(GL_QUADS);
    glColor3f(0.3f, 0.3f, 0.3f); // ��ɫ
    glVertex3f(0, 0, 0);
    glVertex3f(terrainSize - 1, 0, 0);
    glVertex3f(terrainSize - 1, 0, terrainSize - 1);
    glVertex3f(0, 0, terrainSize - 1);
    glEnd();

    glutSwapBuffers();
}

void reshape(int width, int height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)width / (double)height, 1.0, 1000.0);
    glMatrixMode(GL_MODELVIEW);
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'w': angleX -= 5.0f; break;
        case 's': angleX += 5.0f; break;
        case 'a': angleY -= 5.0f; break;
        case 'd': angleY += 5.0f; break;
        case 'q': zoom *= 1.1f; break;
        case 'e': zoom /= 1.1f; break;
    }
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("3D Terrain");

    glEnable(GL_DEPTH_TEST);

    generateTerrain();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
