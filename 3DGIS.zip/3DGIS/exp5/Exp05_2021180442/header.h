#ifndef HEADER_H
#define HEADER_H

#include <GL/glut.h>
#include <stdlib.h>
#include <cmath>
#include <ctime>

// ���δ�С
const int terrainSize = 200;
extern float terrain[terrainSize][terrainSize];

// �ӽǿ��Ʊ���
extern float angleX, angleY;
extern float zoom;

// ��������
void generateTerrain();
void setColor(float height);
void interpolateColor(float height);
void display();
void reshape(int width, int height);
void keyboard(unsigned char key, int x, int y);

#endif // HEADER_H
