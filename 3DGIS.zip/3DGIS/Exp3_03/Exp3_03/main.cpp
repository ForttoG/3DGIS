#include "header.h"
#ifndef GL_BGR
#define GL_BGR 0x80E0
#endif

int lastMouseX = 0;
int lastMouseY = 0;
float rotateX = 0.0f;
float rotateY = 0.0f;


GLuint textures[6]; // Array to store texture IDs
float angle = 0.0f; // Rotation angle

void init(void) {
    glEnable(GL_DEPTH_TEST); // Enable depth testing for 3D
    glEnable(GL_TEXTURE_2D); // Enable texture mapping
    glClearColor(0.0, 0.0, 0.0, 0.0); // Set background color to black
    
    // Load textures
    for (int i = 0; i < 6; i++) {
        char filename[100];
        sprintf(filename, "D:\\demo\\texture%d.bmp", i + 1);
        textures[i] = LoadTexture(filename);
    }
}

void motion(int x, int y) {
    rotateX += (y - lastMouseY) * 0.5f;
    rotateY += (x - lastMouseX) * 0.5f;

    lastMouseX = x;
    lastMouseY = y;

    glutPostRedisplay();
}

// Load texture from BMP file
GLuint LoadTexture(const char * filename) {
    GLuint texture;
    unsigned char header[54];
    unsigned int dataPos;
    unsigned int imageSize;
    unsigned char * data;
    
    FILE * file = fopen(filename, "rb");
    if (!file) {
        std::cerr << "Could not open file " << filename << std::endl;
        return 0;
    }

    if (fread(header, 1, 54, file) != 54) {
        std::cerr << "Not a correct BMP file" << std::endl;
        return 0;
    }

    if (header[0] != 'B' || header[1] != 'M') {
        std::cerr << "Not a correct BMP file" << std::endl;
        return 0;
    }

    dataPos = *(int*)&(header[0x0A]);
    imageSize = *(int*)&(header[0x22]);
    if (imageSize == 0) imageSize = 1024; // Some BMP files do not specify image size, assuming 1024
    if (dataPos == 0) dataPos = 54;

    // Calculate texture width and height
    int width = *(int*)&(header[0x12]);
    int height = *(int*)&(header[0x16]);

    data = new unsigned char[imageSize];
    fread(data, 1, imageSize, file);
    fclose(file);

    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    delete[] data;
    return texture;
}


void display(void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    
    gluLookAt(0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0); // Set camera position
    
    glRotatef(rotateX, 1.0f, 0.0f, 0.0f);
    glRotatef(rotateY, 0.0f, 1.0f, 0.0f);
    
    // Draw the cube with different textures on each face
    for (int i = 0; i < 6; i++) {
        glBindTexture(GL_TEXTURE_2D, textures[i]);
        glBegin(GL_QUADS);
        switch (i) {
            case 0: // Front face
                glTexCoord2f(0.0, 0.0); glVertex3f(-1.0, -1.0,  1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f( 1.0, -1.0,  1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f( 1.0,  1.0,  1.0);
                glTexCoord2f(0.0, 1.0); glVertex3f(-1.0,  1.0,  1.0);
                break;
            case 1: // Back face
                glTexCoord2f(0.0, 0.0); glVertex3f(-1.0, -1.0, -1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f(-1.0,  1.0, -1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f( 1.0,  1.0, -1.0);
                glTexCoord2f(0.0, 1.0); glVertex3f( 1.0, -1.0, -1.0);
                break;
            case 2: // Top face
                glTexCoord2f(0.0, 1.0); glVertex3f(-1.0,  1.0, -1.0);
                glTexCoord2f(0.0, 0.0); glVertex3f(-1.0,  1.0,  1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f( 1.0,  1.0,  1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f( 1.0,  1.0, -1.0);
                break;
            case 3: // Bottom face
                glTexCoord2f(0.0, 1.0); glVertex3f(-1.0, -1.0, -1.0);
                glTexCoord2f(0.0, 0.0); glVertex3f( 1.0, -1.0, -1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f( 1.0, -1.0,  1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f(-1.0, -1.0,  1.0);
                break;
            case 4: // Right face
                glTexCoord2f(0.0, 0.0); glVertex3f( 1.0, -1.0, -1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f( 1.0,  1.0, -1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f( 1.0,  1.0,  1.0);
                glTexCoord2f(0.0, 1.0); glVertex3f( 1.0, -1.0,  1.0);
                break;
            case 5: // Left face
                glTexCoord2f(0.0, 0.0); glVertex3f(-1.0, -1.0, -1.0);
                glTexCoord2f(1.0, 0.0); glVertex3f(-1.0, -1.0,  1.0);
                glTexCoord2f(1.0, 1.0); glVertex3f(-1.0,  1.0,  1.0);
                glTexCoord2f(0.0, 1.0); glVertex3f(-1.0,  1.0, -1.0);
                break;
        }
        glEnd();
    }
    
    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, (GLfloat)w / (GLfloat)h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void idle(void) {
    angle += 0.1; // Increment rotation angle
    if (angle > 360.0) angle -= 360.0;
    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Textured Cube");

    init();
    
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
	glutMotionFunc(motion); // ��motion�����󶨵�����ƶ��¼�
    
    glutMainLoop();
    
    return 0;
}
