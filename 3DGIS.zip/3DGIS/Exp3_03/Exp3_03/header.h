#ifndef HEADER_H
#define HEADER_H

#include <GL/glut.h>
#include <iostream>

extern int lastMouseX;
extern int lastMouseY;

GLuint LoadTexture(const char * filename);

#endif