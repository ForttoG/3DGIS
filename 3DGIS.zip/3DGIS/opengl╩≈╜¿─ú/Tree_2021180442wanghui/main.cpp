#include "header.h"

// ������ȫ�ֱ�������
const double PI = 3.14159265;
int Rebuild = 1;
int Level = 6;
double g_r = 8, g_theta = PI / 2.0, g_phai = PI / 2.0;
float treePos[3] = {0, -2, 4};
float branchRotation[3] = {0, 0, 0};
int randomizeBranches = 0;
float sunAngle = 0.0;
int sunRotate = 0;
int frameCount = 0;
float fps = 0;
int currentTime = 0, previousTime = 0;

GLuint treeTexture;
GLuint leafTexture;
GLuint grassTexture;
GLuint skyboxTextures[6];

// ����һ�����������
float randf() {
    return (float)rand() / (float)RAND_MAX;
}

// ����λͼ�ļ�
BITMAPINFO *LoadDIBitmap(const char *filename, GLubyte **pixels) {
    FILE *fp;
    BITMAPFILEHEADER bmfh;
    BITMAPINFO *bmih;
    long size;

    if((fp = fopen(filename, "rb")) == NULL)
        return NULL;

    if(fread(&bmfh, sizeof(BITMAPFILEHEADER), 1, fp) < 1)
    {
        fclose(fp);
        return NULL;
    }

    if((bmih = (BITMAPINFO *)malloc(sizeof(BITMAPINFOHEADER))) == NULL)
    {
        fclose(fp);
        return NULL;
    }

    if(fread(bmih, sizeof(BITMAPINFOHEADER), 1, fp) < 1)
    {
        free(bmih);
        fclose(fp);
        return NULL;
    }

    if((size = bmih->bmiHeader.biSizeImage) == 0)
        size = (bmih->bmiHeader.biWidth * bmih->bmiHeader.biBitCount + 7) / 8
               * abs(bmih->bmiHeader.biHeight);

    if((*pixels = (GLubyte *)malloc(size)) == NULL)
    {
        free(bmih);
        fclose(fp);
        return NULL;
    }

    fseek(fp, bmfh.bfOffBits, SEEK_SET);

    if(fread(*pixels, 1, size, fp) < size)
    {
        free(bmih);
        free(*pixels);
        fclose(fp);
        return NULL;
    }

    fclose(fp);
    return bmih;
}

// ��ʼ��OpenGL����
void init() {
    GLfloat light_position[] = { 5.0, 5.0, 0.0, 1.0 };
    GLfloat light_ambient[]  = { 0.2, 0.2, 0.2, 1.0 };
    GLfloat light_diffuse[]  = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
}

// ��������
void LoadTexture(const char* filename) {
    GLubyte *pixels;
    BITMAPINFO *info;

    info = LoadDIBitmap(filename, &pixels);
    if(info == NULL)
    {
        fprintf(stderr, "Error loading texture\n");
        exit(1);
    }

    glGenTextures(1, &treeTexture);
    glBindTexture(GL_TEXTURE_2D, treeTexture);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, info->bmiHeader.biWidth, abs(info->bmiHeader.biHeight), 0,
                 GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);

    free(info);
    free(pixels);
}

void LoadLeafTexture(const char* filename) {
    GLubyte *pixels;
    BITMAPINFO *info;

    info = LoadDIBitmap(filename, &pixels);
    if(info == NULL)
    {
        fprintf(stderr, "Error loading leaf texture\n");
        exit(1);
    }

    glGenTextures(1, &leafTexture);
    glBindTexture(GL_TEXTURE_2D, leafTexture);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, info->bmiHeader.biWidth, abs(info->bmiHeader.biHeight), 0,
                 GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);

    free(info);
    free(pixels);
}

void LoadGrassTexture(const char* filename) {
    GLubyte *pixels;
    BITMAPINFO *info;

    info = LoadDIBitmap(filename, &pixels);
    if(info == NULL)
    {
        fprintf(stderr, "Error loading grass texture\n");
        exit(1);
    }

    glGenTextures(1, &grassTexture);
    glBindTexture(GL_TEXTURE_2D, grassTexture);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, info->bmiHeader.biWidth, abs(info->bmiHeader.biHeight), 0,
                 GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);

    free(info);
    free(pixels);
}

void LoadSkyboxTextures() {
    const char* skyboxFiles[6] = {
        "pictures/skybox/right.bmp",
        "pictures/skybox/left.bmp",
        "pictures/skybox/top.bmp",
        "pictures/skybox/bottom.bmp",
        "pictures/skybox/front.bmp",
        "pictures/skybox/back.bmp"
    };

    glGenTextures(6, skyboxTextures);

    for (int i = 0; i < 6; i++)
    {
        GLubyte *pixels;
        BITMAPINFO *info;

        info = LoadDIBitmap(skyboxFiles[i], &pixels);
        if(info == NULL)
        {
            fprintf(stderr, "Error loading skybox texture: %s\n", skyboxFiles[i]);
            exit(1);
        }

        glBindTexture(GL_TEXTURE_2D, skyboxTextures[i]);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, info->bmiHeader.biWidth, abs(info->bmiHeader.biHeight), 0,
                     GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);

        free(info);
        free(pixels);
	}
}

// �������֧��ת�Ƕ�
void RandomizeBranchRotations() {
    for (int i = 0; i < 3; i++) {
        branchRotation[i] = randf() * 360.0f;
    }
}

// �ݹ����ɷ�����
void FractalTree(int level) {
    long savedseed;

    if (level == Level)
    {
        glPushMatrix();
        glRotatef(60+randf()*120, 0, 1, 0);
        glCallList(STEMANDLEAVES);
        glPopMatrix();
    }
    else
    {
        glCallList(STEM);

        glPushMatrix();
        glTranslatef(0, 1, 0);
        glScalef(0.7, 0.7, 0.7);

        //������������������֦�����3����������֦Ӧ�������ת
        if (randomizeBranches && level >= 2) {
            glRotatef(branchRotation[0], 1, 0, 0);
            glRotatef(branchRotation[1], 0, 1, 0);
            glRotatef(branchRotation[2], 0, 0, 1);
        }

        savedseed = rand();
        glPushMatrix();
        glRotatef(0+ randf()*90, 0, 1, 0);
        glRotatef(30 + randf()*30, 0, 0, 1);
        FractalTree(level + 1);
        glPopMatrix();

        srand(savedseed);
        savedseed = rand();
        glPushMatrix();
        glRotatef(180 + randf()*90, 0, 1, 0);
        glRotatef(30 + randf()*30, 0, 0, 1);
        FractalTree(level + 1);
        glPopMatrix();

        srand(savedseed);
        savedseed = rand();
        glPushMatrix();
        glRotatef(90 + randf()*90, 0, 1, 0);
        glRotatef(30 + randf()*30, 0, 0, 1);
        FractalTree(level + 1);
        glPopMatrix();

        glPopMatrix();
    }
}

// �������ڴ�Сʱ�Ļص�����
static void resize(int w, int h) {
    glViewport(0,0,(GLsizei)w,(GLsizei)h) ;
    glMatrixMode(GL_PROJECTION) ;
    glLoadIdentity() ;
    gluPerspective(60.0,(GLfloat)w/(GLfloat)h,0.2,300.0) ;
    glMatrixMode(GL_MODELVIEW) ;
    glLoadIdentity() ;
}

// ���Ƶ���
void drawGround() {
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, grassTexture);
    glColor3f(1.0f, 1.0f, 1.0f);

    GLUquadric* quad = gluNewQuadric();
    gluQuadricTexture(quad, GL_TRUE);

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
    glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
    gluDisk(quad, 0.0f, 20.0f, 32, 32);
    glPopMatrix();

    gluDeleteQuadric(quad);

    glDisable(GL_TEXTURE_2D);
}

// ���Ƶƹ�
void drawSun(GLfloat x, GLfloat y, GLfloat z) {
    glPushMatrix();
    glTranslatef(x, y, z);
    glColor3f(1.0, 1.0, 0.0); // ��ɫ�����ƹ�
    glutSolidSphere(0.5, 20, 20);
    glPopMatrix();
}

// ������պ�
void DrawSkybox(float size) {
    glPushMatrix();
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    glColor3f(1, 1, 1);

    // Right face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[0]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(size, -size, -size);
    glTexCoord2f(1, 0); glVertex3f(size, -size, size);
    glTexCoord2f(1, 1); glVertex3f(size, size, size);
    glTexCoord2f(0, 1); glVertex3f(size, size, -size);
    glEnd();

    // Left face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[1]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-size, -size, size);
    glTexCoord2f(1, 0); glVertex3f(-size, -size, -size);
    glTexCoord2f(1, 1); glVertex3f(-size, size, -size);
    glTexCoord2f(0, 1); glVertex3f(-size, size, size);
    glEnd();

    // Top face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[2]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-size, size, -size);
    glTexCoord2f(1, 0); glVertex3f(size, size, -size);
    glTexCoord2f(1, 1); glVertex3f(size, size, size);
    glTexCoord2f(0, 1); glVertex3f(-size, size, size);
    glEnd();

    // Bottom face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[3]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-size, -size, size);
    glTexCoord2f(1, 0); glVertex3f(size, -size, size);
    glTexCoord2f(1, 1); glVertex3f(size, -size, -size);
    glTexCoord2f(0, 1); glVertex3f(-size, -size, -size);
    glEnd();

    // Front face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[4]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-size, -size, -size);
    glTexCoord2f(1, 0); glVertex3f(size, -size, -size);
    glTexCoord2f(1, 1); glVertex3f(size, size, -size);
    glTexCoord2f(0, 1); glVertex3f(-size, size, -size);
    glEnd();

    // Back face
    glBindTexture(GL_TEXTURE_2D, skyboxTextures[5]);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(size, -size, size);
    glTexCoord2f(1, 0); glVertex3f(-size, -size, size);
    glTexCoord2f(1, 1); glVertex3f(-size, size, size);
    glTexCoord2f(0, 1); glVertex3f(size, size, size);
    glEnd();

    glEnable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glPopMatrix();
}

// ����������ʾ�б�
void CreateTreeLists() {
    GLUquadricObj *cylquad = gluNewQuadric();
    int i;

    glNewList(STEM, GL_COMPILE);
    glCallList(TREE_MAT);
    glPushMatrix();
    glRotatef(-90, 1, 0, 0);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    gluQuadricTexture(cylquad, GL_TRUE);
    gluCylinder(cylquad, 0.15, 0.12, 1, 10, 2);
    glDisable(GL_TEXTURE_2D);

    glPopMatrix();
    glEndList();

    glNewList(LEAF, GL_COMPILE);
    glBegin(GL_TRIANGLES);
    glNormal3f(-0.1, 0, 0.25);
    glVertex3f(0, 0, 0);
    glVertex3f(0.5, 0.5, 0.2);
    glVertex3f(0, 1.0, 0);
    glNormal3f(0.2, 0, 0.5);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1.0, 0);
    glVertex3f(-0.5, 0.5, 0.2);
    glEnd();
    glEndList();

    glNewList(STEMANDLEAVES, GL_COMPILE);
    glPushMatrix();
    glPushAttrib(GL_LIGHTING_BIT);
    glCallList(STEM);
    glCallList(LEAF_MAT);
    for(i = 0; i < 3; i++)
    {
        glTranslatef(0, 0.333, 0);
        glRotatef(90, 0, 1, 0);
        glPushMatrix();
        glRotatef(0, 0, 1, 0);
        glRotatef(50, 1, 0, 0);
        glCallList(LEAF);
        glPopMatrix();
        glPushMatrix();
        glRotatef(180, 0, 1, 0);
        glRotatef(60, 1, 0, 0);
        glCallList(LEAF);
        glPopMatrix();
    }
    glPopAttrib();
    glPopMatrix();
    glEndList();

    gluDeleteQuadric(cylquad);

	glNewList(LEAF, GL_COMPILE);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, leafTexture);
    glBegin(GL_TRIANGLES);
    glNormal3f(-0.1, 0, 0.25);
    glTexCoord2f(0.0, 0.0); glVertex3f(0, 0, 0);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, 0.5, 0.2);
    glTexCoord2f(0.5, 1.0); glVertex3f(0, 1.0, 0);
    glNormal3f(0.2, 0, 0.5);
    glTexCoord2f(0.0, 0.0); glVertex3f(0, 0, 0);
    glTexCoord2f(0.5, 1.0); glVertex3f(0, 1.0, 0);
    glTexCoord2f(1.0, 0.0); glVertex3f(-0.5, 0.5, 0.2);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEndList();
}

// ���¹�Դλ��
void updateSunPosition() {
    if (sunRotate) {
        sunAngle += 2.0; // ������ת�ٶ�
        if (sunAngle >= 360.0) {
            sunAngle -= 360.0;
        }
    }

    // ��������λ����(0, 0, 0)
    GLfloat radius = 5.0;
    GLfloat sunX = radius * cos(sunAngle * PI / 180.0);
    GLfloat sunY = 5.0; // ̫���ĸ߶ȿ��Թ̶�
    GLfloat sunZ = radius * sin(sunAngle * PI / 180.0);

    GLfloat sun_position[] = { sunX, sunY, sunZ, 1.0 };
    glLightfv(GL_LIGHT0, GL_POSITION, sun_position); // ���¹�Դλ��
}

// ���ò���
void SetupMaterials() {
    GLfloat tree_ambuse[] =   { 1.0, 1.0, 1.0, 1.0 };
    GLfloat tree_specular[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat tree_shininess[] = { 10 };

    GLfloat leaf_ambuse[] =   { 1.0, 1.0, 1.0, 1.0 };
    GLfloat leaf_specular[] = { 0.0, 0.8, 0.0, 1.0 };
    GLfloat leaf_shininess[] = { 10 };

    glNewList(TREE_MAT, GL_COMPILE);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, tree_ambuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, tree_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, tree_shininess);
    glEndList();

    glNewList(LEAF_MAT, GL_COMPILE);
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, leaf_ambuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, leaf_specular);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, leaf_shininess);
    glEndList();
}

void displayFPS() {
    //����FPS
    frameCount++;
    currentTime = glutGet(GLUT_ELAPSED_TIME);
    int timeInterval = currentTime - previousTime;

    if (timeInterval > 1000) {
        fps = frameCount / (timeInterval / 1000.0f);
        previousTime = currentTime;
        frameCount = 0;
    }

    // ����FPS��ʾ��λ��
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 800, 0, 600);  // ��������ͶӰ��ƥ�䴰�ڴ�С

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    // �����ı���ɫ
    glColor3f(1.0, 1.0, 1.0);

    // ��Ⱦ�ı�
    glRasterPos2f(10, 580);  // ���ı��������Ͻ�
    char fpsString[50];
    sprintf(fpsString, "FPS: %.2f", fps);

    for (int i = 0; fpsString[i] != '\0'; i++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, fpsString[i]);
    }

    // �ָ�ԭʼͶӰ����
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}


// ��ʾ�ص�����
static void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	updateSunPosition();

    // ��������λ����(0, 0, 0)
    GLfloat radius = 5.0;
    GLfloat sunX = radius * cos(sunAngle * PI / 180.0);
    GLfloat sunY = 5.0; // ̫���ĸ߶ȿ��Թ̶�
    GLfloat sunZ = radius * sin(sunAngle * PI / 180.0);

    drawSun(sunX, sunY, sunZ);

    glLoadIdentity();
    glTranslatef(treePos[0], treePos[1], treePos[2]);
    gluLookAt(g_r*sin(g_phai)*cos(g_theta),
              g_r*cos(g_phai),
              g_r*sin(g_phai)*sin(g_theta), 0,0,0, 0,
              sin(g_phai)>=0?1:-1,0);

    // ������պ�
    DrawSkybox(100.0f);
	drawGround();

    if(Rebuild)
    {
        glNewList(TREE, GL_COMPILE);
        FractalTree(0);
        glEndList();
        Rebuild = 0;
        randomizeBranches = 0;  // ����
    }
    glCallList(TREE);

	displayFPS();

    glutSwapBuffers();
}

// ���̻ص�����
static void key(unsigned char key, int x, int y) {
    switch (key)
    {
    case 27 :
        exit(0);
        break;
    case '=':
        if(Level<8) Level++;
        Rebuild = 1;
        break;
    case '-':
        if(Level>0) Level--;
        Rebuild = 1;
        break;
    case 'r':
        Rebuild = 1;
        break;
    case 'w':
        g_phai += PI/180.0;
        break;
    case 's':
        g_phai -= PI/180.0;
        break;
    case 'a':
        g_theta += PI/180.0;
        break;
    case 'd':
        g_theta -= PI/180.0;
        break;
    case 'q':
        g_r += 0.1;
        break;
    case 'e':
        g_r -= 0.1;
        break;
    case 'c':
        randomizeBranches = 1;
        RandomizeBranchRotations();
        Rebuild = 1;
        break;
    case 'g':
        sunRotate = !sunRotate;
        break;

    }
    glutPostRedisplay();
}

// ����ʱ�Ļص�����
static void idle() {
    glutPostRedisplay();
}

// ������
int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitWindowSize(1280, 720);
    glutInitWindowPosition(10, 10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("Shapes");
    init();

    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key);
    glutIdleFunc(idle);

    GLfloat light_position[] = { -15.0, 15.0, 0, 0.0 };
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    SetupMaterials();
    LoadSkyboxTextures();  // ������պ�����
    LoadTexture("pictures/tree.bmp");
    LoadLeafTexture("pictures/leaf.bmp");
    LoadGrassTexture("pictures/grass.bmp");
    CreateTreeLists();

    srand((unsigned int)time(NULL));
    glutMainLoop();

    return EXIT_SUCCESS;
}
