#ifndef HEADER_H
#define HEADER_H

#include <windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdio.h>

// OpenGL��������
#define GL_CLAMP_TO_EDGE 0x812F

// ���νṹ����س���
#define TREE 6
#define STEM 1
#define LEAF 2
#define LEAF_MAT 3
#define TREE_MAT 4
#define STEMANDLEAVES 5

// ������ȫ�ֱ�������
extern const double PI;
extern int Rebuild;
extern int Level;
extern double g_r, g_theta, g_phai;
extern float treePos[3];
extern float branchRotation[3];
extern int randomizeBranches;
extern float sunAngle;
extern int sunRotate;
extern GLuint treeTexture;
extern GLuint leafTexture;
extern GLuint grassTexture;
extern GLuint skyboxTextures[6];

// ��������
float randf();
BITMAPINFO *LoadDIBitmap(const char *filename, GLubyte **pixels);
void init();
void LoadTexture(const char* filename);
void LoadLeafTexture(const char* filename);
void LoadGrassTexture(const char* filename);
void LoadSkyboxTextures();
void RandomizeBranchRotations();
void FractalTree(int level);
static void resize(int w, int h);
void drawGround();
void drawSun(GLfloat x, GLfloat y, GLfloat z);
void DrawSkybox(float size);
void CreateTreeLists();
void updateSunPosition();
void SetupMaterials();
static void display();
static void key(unsigned char key, int x, int y);
static void idle();

#endif
